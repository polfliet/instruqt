<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet"/>

<style>

html {
    background-color: rgb(28, 42, 47);
}

body {
    outline: none;
    border: 1px solid rgb(124, 151, 153);
    border-radius: 0.25rem;
    /*border: none;*/
}
.markdown-body {
    font-family: 'Open Sans';
    color: rgb(124, 151, 153);
}

.markdown-body a {
    color: rgb(112, 204, 211);
}

h1,h2,h3,h4,h5,h6 {
    color: rgb(256, 256, 256);
}
</style>

